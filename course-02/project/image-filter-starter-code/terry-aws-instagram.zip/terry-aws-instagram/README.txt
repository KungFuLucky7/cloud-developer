Udagram Image Filtering Microservice on AWS

GitHub Repo develop branch URL:
https://github.com/KungFuLucky7/cloud-developer/tree/develop/course-02/project/image-filter-starter-code

Service API URL:
http://twong-app-dev.us-west-1.elasticbeanstalk.com/
e.g. GET http://twong-app-dev.us-west-1.elasticbeanstalk.com/filteredimage?image_url=https://static.boredpanda.com/blog/wp-content/uploads/2014/06/happy-dog-maru-shiba-inu-7.jpg

